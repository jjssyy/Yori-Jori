<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
import "./components/css/style.scss";
export default {
  name: "app"
};
</script>
