<template>
    <div class="user" id="error">
        <h1>요청이 실패했습니다.</h1>
        <div>
            <router-link to="/" class="btn--text">로그인 페이지로 돌아가기</router-link>
        </div>
    </div>
</template>