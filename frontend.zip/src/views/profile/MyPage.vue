

<template>
  <div>
    <div class="wrapC">
      <h1>프로필</h1>
      
    </div>
  </div>
</template>

<script>
export default {
  
}
</script>