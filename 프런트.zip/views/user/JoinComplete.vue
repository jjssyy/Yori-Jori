<template>
    <div class="user" id="joinComplete">
        <div class="wrapC">
            <h1>
                회원가입 인증 메일이 발송되었습니다.
            <br />이메일을 확인해주세요.
            </h1>
        </div>
        <div class="add-option">
            <div class="wrap" style="text-align:center">
                <router-link to="#" class="btn--text">메일 재발송</router-link>
                &nbsp;&nbsp;&nbsp;
                <router-link to="/" class="btn--text">로그인 페이지로 돌아가기</router-link>
            </div>
        </div>
    </div>
    
</template>

<script>

</script>
